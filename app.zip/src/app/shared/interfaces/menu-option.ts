export interface IMenuOption {
    title: string,
    icon: string,
    active: boolean
}
