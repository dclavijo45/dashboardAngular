export interface IUpdate {
    id: number,
    img_profile: string,
    name: string,
    transcription: string,
    reported_time: string
}
