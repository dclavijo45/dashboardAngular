export interface IBadge {
    icon: string,
    percent: number,
    title: string,
    price: number,
    date: string,
    color: string
}
